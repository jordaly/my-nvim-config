vim.opt.scrolloff = 10
vim.o.number = true
vim.o.relativenumber = true
vim.opt.incsearch = true
vim.o.foldcolumn = "1"
vim.o.foldlevel = 99

vim.g.copilot_assume_mapped = true
vim.opt.incsearch = true
vim.opt.hlsearch = true
